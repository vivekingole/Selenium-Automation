package com.cg.demo.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelReader {

	
	public static void main(String args[]){
		
		String projectpath = System.getProperty("user.dir");
		String filepath = projectpath + "/testdata";
		String filename = "addressdata.xlsx";
		String sheetname = "addressdata";
		Object data[][] = ExcelReader.getExcelDataAsTable(filepath,filename,sheetname);
		//ExcelReader.readExcel(filepath,filename,sheetname);
		for(Hashtable<String, String> tab : data){
			Hashtable<String, String> table = (Hashtable<String, String>) tab;
				System.out.println(table.get("city"));
		}
		//System.out.println(data[0]);	
	}

	public static void readExcel(String filepath, String filename, String sheetname) {		
		File file;
		try {
			file = new File(filepath+"/"+filename);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetname);
			int rowcount = sheet.getLastRowNum();
			for(int r = 0; r <= rowcount ; r++){
				Row row = sheet.getRow(r);
				System.out.println("Col Count : "+row.getLastCellNum());
				for(int c=0 ; c < row.getLastCellNum(); c++){
					Cell cell = row.getCell(c);
					System.out.print(r+" "+c +" : " );
					System.out.print(cell.getStringCellValue()+"\t");
				}
				System.out.println();
			}
		} catch (Exception e) {	
			System.out.println("Exception : ");
			e.printStackTrace();
		}
	}

	public static Object[][] getExcelDataAsTable(String filepath, String filename, String sheetname) {		
		File file;
		try {
			file = new File(filepath+"/"+filename);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetname);
			int rowcount = sheet.getLastRowNum();
			rowcount--;
			int colcount = 0;
			Object [][]data = new Object[rowcount][1];
			Hashtable<String, String> table = null;
			Row keyrow = sheet.getRow(0);
			System.out.println("Rowcnt : "+rowcount);
			for(int r = 1; r <= rowcount ; r++){
				Row row = sheet.getRow(r);
				colcount = row.getLastCellNum();
				table = new Hashtable();
				for(int c=0 ; c < colcount; c++){
					String key = keyrow.getCell(c).getStringCellValue();
					String val = row.getCell(c).getStringCellValue();
					table.put(key, val);
				}
				data[r-1][0] = table;
				System.out.println(table);
			}
			return data;
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return null;
	}

	public static Object[][] getExcelDataAsArray(String filepath, String filename, String sheetname) {		
		File file;
		try {
			file = new File(filepath+"/"+filename);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetname);
			int rowcount = sheet.getLastRowNum();	
			System.out.println("Row : "+rowcount);
			int colcount = 0;
			Object [][]data = new Object[rowcount][];
			for(int r = 1; r < rowcount ; r++){
				Row row = sheet.getRow(r);
				colcount = row.getLastCellNum();
				System.out.println("Col : "+colcount);
				data[r-1] = new Object[colcount];
				for(int c=0 ; c < colcount; c++){
					String val = row.getCell(c).getStringCellValue();
					System.out.println(val);
					data[r-1][c] = val;
				}
			}
			return data;
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return null;
	}
}
