package Lab13;

import java.io.IOException;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab13 {

	static WebDriver driver;

	public static void main(String args[]) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/ChromeDriverPath"));
		driver = new ChromeDriver();
		driver.get(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/AppURL"));
		driver.manage().window().maximize();
		
		WebElement des = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/des")));
		des.click();

		WebElement mac = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/mac")));
		mac.click();

		String head = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/head"))).getText();
		Assert.assertEquals("Mac", head);

		WebElement sort = driver.findElement(By.id(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/sort")));
		Select s = new Select(sort);
		s.selectByIndex(1);

		WebElement cart = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/cart")));
		cart.click();

		WebElement search = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/search")));
		search.clear();
		search.sendKeys("Mobile");

		WebElement srch = driver.findElement(By.xpath(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/srch")));
		srch.click();

		WebElement clr = driver.findElement(By.id(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/clr")));
		clr.clear();

		WebElement check = driver.findElement(By.id(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/check")));
		check.click();

		WebElement ser = driver.findElement(By.id(XMLReader.getValue("./src/Lab13/ObjectRepository.xml","//objects/ser")));
		ser.click();

		Thread.sleep(3000);
		driver.close();
	}
}