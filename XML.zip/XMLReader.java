package Lab13;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;



public class XMLReader {

	public static String getValue(String filepath, String nodepath) {
		 SAXReader saxreader = new SAXReader();
		 try {
			FileInputStream fis = new FileInputStream(filepath);
			Document doc =  saxreader.read(fis);
			String value =doc.selectSingleNode(nodepath).getText();
			return value;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		 return null;
	}
}
